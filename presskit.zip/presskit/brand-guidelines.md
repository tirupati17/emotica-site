# Emotica Brand Guidelines

**Version 1.0** | March 2026
**Prepared by** Emotica Team

---

## 1. Brand Identity

Emotica is an emotional intelligence companion that helps people understand their inner world through journaling, mood tracking, AI coaching, and mental wellness exercises. The visual identity reflects this mission: **soft, approachable, and emotionally resonant** — never clinical or sterile.

### Brand Essence
- **Warm** — colors that feel like feelings
- **Cosmic** — depth and wonder in self-exploration
- **Gentle** — pastel palette that never overwhelms
- **Personal** — customizable accent colors and themes

---

## 2. Logo & App Icon

The Emotica app icon is the primary brand mark. It uses a **violet-purple gradient** as the signature brand color, establishing the visual identity across all platforms.

- **Primary Brand Color**: Deep Violet `#1F174A` / `rgb(31, 23, 74)`
- **Icon Background**: Cosmic purple gradient
- Always display the icon with adequate spacing (minimum 8px clear space)
- Do not stretch, rotate, or alter the icon proportions

---

## 3. Color System

Emotica's color system is built around three layers: **brand accent**, **emotion palette**, and **theme surfaces**.

### 3.1 Accent Colors

The default accent is **Violet**. Users can personalize with 8 accent options:

| Name | Hex | RGB | SwiftUI |
|------|-----|-----|---------|
| **Indigo** | `#4F46E5` | `79, 70, 229` | `.indigo` |
| **Emerald** | `#059669` | `5, 150, 105` | — |
| **Rose** | `#E11D48` | `225, 29, 72` | — |
| **Amber** | `#D97706` | `217, 119, 6` | — |
| **Ocean** | `#0891B2` | `8, 145, 178` | — |
| **Violet** (default) | `#7C3AED` | `124, 58, 237` | — |
| **Coral** | `#F97316` | `249, 115, 22` | — |
| **Slate** | `#64748B` | `100, 116, 139` | — |

Free: Indigo, Slate. Premium: all others.

### 3.2 Emotion Category Colors

Each emotion category has two color variants:
- **Vibrant** — used for text, icons, and accents on dark backgrounds
- **Palette** — soft pastel used for clouds, chips, backgrounds, and cards

#### Vibrant (bold, for emphasis)

| Category | SwiftUI | Approximate Hex |
|----------|---------|-----------------|
| **Joyful** | `.pink` | `#FF2D55` |
| **Peaceful** | `.green` | `#34C759` |
| **Empowered** | `.purple` | `#AF52DE` |
| **Difficult** | `.red` | `#FF3B30` |
| **Sad** | `.blue` | `#007AFF` |
| **Fearful** | `.orange` | `#FF9500` |
| **Self Conscious** | `.yellow` | `#FFCC00` |
| **Low Energy** | `.blue` | `#007AFF` |

#### Palette (pastel, for surfaces)

| Category | Hex | RGB (0-255) | SwiftUI `Color(red:green:blue:)` |
|----------|-----|-------------|----------------------------------|
| **Joyful** | `#FFCCE6` | `255, 204, 230` | `(1.0, 0.8, 0.9)` |
| **Peaceful** | `#CCFFCC` | `204, 255, 204` | `(0.8, 1.0, 0.8)` |
| **Empowered** | `#E6CCFF` | `230, 204, 255` | `(0.9, 0.8, 1.0)` |
| **Difficult** | `#FFB3B3` | `255, 179, 179` | `(1.0, 0.7, 0.7)` |
| **Sad / Low Energy** | `#CCE6FF` | `204, 230, 255` | `(0.8, 0.9, 1.0)` |
| **Fearful** | `#FFE6B3` | `255, 230, 179` | `(1.0, 0.9, 0.7)` |
| **Self Conscious** | `#FFFFB3` | `255, 255, 179` | `(1.0, 1.0, 0.7)` |

These palette colors are the **signature Emotica look** — they color the mental sky clouds, emotion chips, category pills, and check-in UI. They must not be changed without brand approval.

### 3.3 Trigger (Impact) Category Colors

#### Vibrant

| Category | SwiftUI | Approximate Hex |
|----------|---------|-----------------|
| **Wellness** | `.teal` | `#30B0C7` |
| **Personal** | `.purple` | `#AF52DE` |
| **Social** | `.orange` | `#FF9500` |
| **Life** | `.green` | `#34C759` |
| **World** | `.gray` | `#8E8E93` |

#### Palette (pastel, for surfaces)

| Category | Hex | RGB (0-255) | SwiftUI `Color(red:green:blue:)` |
|----------|-----|-------------|----------------------------------|
| **Wellness** | `#CCFFFF` | `204, 255, 255` | `(0.8, 1.0, 1.0)` |
| **Personal** | `#E6CCFF` | `230, 204, 255` | `(0.9, 0.8, 1.0)` |
| **Social** | `#FFE6CC` | `255, 230, 204` | `(1.0, 0.9, 0.8)` |
| **Life** | `#CCFFCC` | `204, 255, 204` | `(0.8, 1.0, 0.8)` |
| **World** | `#E6E6E6` | `230, 230, 230` | `(0.9, 0.9, 0.9)` |

### 3.4 Intensity Gradient

Emotion intensity uses a **blue-to-purple gradient** that deepens with strength:

| Level | Hex | RGB (0-255) | SwiftUI `Color(red:green:blue:)` |
|-------|-----|-------------|----------------------------------|
| **Low** | `#99CCFF` | `153, 204, 255` | `(0.6, 0.8, 1.0)` |
| **Noticeable** | `#8099FF` | `128, 153, 255` | `(0.5, 0.6, 1.0)` |
| **Medium** | `#9980FF` | `153, 128, 255` | `(0.6, 0.5, 1.0)` |
| **Strong** | `#B366E6` | `179, 102, 230` | `(0.7, 0.4, 0.9)` |
| **Maximum** | `#CC4DCC` | `204, 77, 204` | `(0.8, 0.3, 0.8)` |

### 3.5 Neutral

| Token | Hex | RGB | Usage |
|-------|-----|-----|-------|
| **Neutral Log** | `#CCD1F2` | `204, 209, 242` | `(0.8, 0.82, 0.95)` — default log/entry color |

---

## 4. Theme System

Emotica offers 8 themes. The **Cosmic Light (Complete White)** theme is the brand's signature look and default for new users.

### 4.1 Surface Colors

| Theme | Primary BG | Hex | Secondary BG | Hex |
|-------|-----------|-----|-------------|-----|
| **Complete White** | Pure White | `#FFFFFF` | Off White | `#F5F5F5` |
| **Light** | Soft White | `#F2F2F2` | Pure White | `#FFFFFF` |
| **Dark** | Pure Black | `#000000` | Dark Charcoal | `#14141A` |
| **Cosmic Dark** | Deep Space | `#0D0526` | Nebula | `#1A0D40` |
| **Cosmic Pink** | Deep Rose | `#1F0514` | Rose Nebula | `#330D26` |
| **Cosmic Green** | Deep Forest | `#05140D` | Emerald Nebula | `#0D261A` |
| **Cosmic Extra Dark** | True Black | `#000000` | Ultra Deep | `#08030F` |
| **Cosmic Black** | Absolute Black | `#000000` | Darkest Gray | `#0F0F0F` |

### 4.2 Text Colors

| Token | Light Themes | Dark/Cosmic Themes |
|-------|-------------|-------------------|
| **Primary Text** | Black 90% `rgba(0,0,0,0.9)` | White `#FFFFFF` |
| **Secondary Text** | Black 60% `rgba(0,0,0,0.6)` | White 60% `rgba(255,255,255,0.6)` |
| **Tertiary Text** | Black 40% `rgba(0,0,0,0.4)` | White 40% `rgba(255,255,255,0.4)` |

---

## 5. Typography

**Primary Font**: Lexend (Google Fonts, variable weight)
**Fallback**: SF Rounded (system)

| Style | Font | Size | Weight |
|-------|------|------|--------|
| **Title** | Lexend | 34pt | Bold |
| **Headline** | Lexend | 17pt | SemiBold |
| **Body** | Lexend | 17pt | Regular |
| **Caption** | Lexend | 12pt | Regular |

Usage:
- All UI text uses Lexend
- Users can switch to SF Rounded in settings
- Never mix both in the same screen

---

## 6. Visual Language

### 6.1 Mental Sky

The "Mental Sky" is Emotica's signature UI metaphor. Emotions appear as **soft clouds** colored by their category palette color on a clean white/cosmic background.

- Clouds use `paletteColor` (pastel) — never vibrant
- Cloud saturation can be boosted up to 1.5x for emphasis (`saturated(by:)`)
- The sky background matches the current theme surface
- Clouds drift and can be dragged — they feel alive

### 6.2 Chips & Pills

Emotion and trigger chips use:
- **Background**: `paletteColor` at 25-35% opacity (light themes) or 30-80% (dark themes)
- **Border**: `paletteColor` at 60-90% opacity, 1-2px
- **Text**: `primaryText` color from theme
- **Selected state**: increased opacity + 2px border

### 6.3 Gradients

Cosmic themes use subtle gradients that blend primary and secondary backgrounds with a color accent:
- Cosmic Dark: deep purple + blue glow
- Cosmic Pink: deep rose + pink glow
- Cosmic Green: deep forest + green glow
- Light themes: minimal gradient, near-flat surfaces

---

## 7. Iconography

- **Emotion icons**: SF Symbols (system-provided)
- **Tab bar**: SF Symbols filled variants (`cloud.fill`, `chart.bar.xaxis`, `message.fill`, `figure.mind.and.body`)
- **Navigation**: SF Symbols at 16-18pt
- Icon tint follows the current accent color

---

## 8. Brand Voice

| Do | Don't |
|----|-------|
| Warm, empathetic, encouraging | Clinical, judgmental, preachy |
| "Express how you feel" | "Log your symptoms" |
| "Your mental sky" | "Your mood dashboard" |
| "Check in with yourself" | "Submit an entry" |

---

## 9. Platform Consistency

Emotica runs on iPhone, iPad, Mac (Catalyst), and Apple Watch. Brand colors and typography are identical across all platforms. Platform-specific adaptations:

- **iPhone**: Tab bar at bottom, full cloud interaction
- **iPad**: Sidebar navigation, wider layouts
- **Mac**: Menu bar shortcuts, hover states, sidebar always visible
- **Apple Watch**: Crown-based check-in, simplified color palette

---

## 10. Press Kit Assets

### App Information
- **App Name**: Emotica
- **Tagline**: Your emotional intelligence companion
- **Developer**: Tirupati Balan & Iraida Razenkova
- **Platforms**: iOS 17+, iPadOS 17+, macOS 15+ (Catalyst), watchOS
- **Bundle ID**: `com.celerstudio.emotica`
- **App Store**: [Link]
- **Website**: [emotica.app]

### Key Features
- Mental Sky cloud visualization
- 35 emotions across 8 categories
- AI Coach powered by Gemini
- Guided meditations, affirmations, and sleep sounds
- HealthKit integration (HRV, sleep, workouts)
- 8 customizable themes
- Privacy-first: on-device processing available

### Color Quick Reference

**Brand Deep Violet**: `#1F174A`

**Emotion Pastels**: `#FFCCE6` `#CCFFCC` `#E6CCFF` `#FFB3B3` `#CCE6FF` `#FFE6B3` `#FFFFB3`

**Intensity Spectrum**: `#99CCFF` -> `#8099FF` -> `#9980FF` -> `#B366E6` -> `#CC4DCC`

---

*These guidelines are the source of truth for all Emotica visual design. When in doubt, reference the Cosmic Light (Complete White) theme with Violet accent as the canonical brand presentation.*
