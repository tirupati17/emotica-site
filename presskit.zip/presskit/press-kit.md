# Emotica Press Kit

---

## About Emotica

Emotica is an emotional intelligence app that helps people understand, express, and improve their inner world. Through a unique "Mental Sky" visualization, AI coaching, guided exercises, and deep analytics, Emotica turns emotional awareness into a daily practice.

Designed for iPhone, iPad, Mac, and Apple Watch.

---

## App Details

| | |
|---|---|
| **App Name** | Emotica |
| **Developer** | Tirupati Balan & Iraida Razenkova |
| **Category** | Health & Fitness / Mental Wellness |
| **Platforms** | iOS 17+, iPadOS 17+, macOS 15+ (Catalyst), watchOS |
| **Languages** | English, Spanish, Russian |
| **Pricing** | Free with Premium (Monthly / Yearly / Lifetime) |
| **Bundle ID** | `com.celerstudio.emotica` |

---

## Key Features

### Mental Sky
Express emotions as soft clouds that float across your personal sky. Each cloud is colored by emotion category — pink for joy, green for peace, lavender for empowerment. Clouds drift after 24 hours into your history, creating a living map of your emotional landscape.

### 35 Emotions, 8 Categories
A research-backed emotion model spanning Joyful, Peaceful, Empowered, Difficult, Sad, Fearful, Self-Conscious, and Low Energy. Each emotion has a unique SF Symbol icon and color identity.

### AI Coach (Emotica)
Conversational AI powered by Google Gemini that understands your emotional patterns. Context-aware coaching that references your journal history to provide personalized insights.

### Guided Exercises
Meditations, affirmations, and sleep sounds — recommended based on your recent emotional reflections. Full background playback with lock screen and Dynamic Island controls.

### Deep Analytics
Charts and insights powered by SwiftCharts. Weekly synthesis, emotion frequency maps, trigger correlation analysis, and streak tracking with Game Center integration.

### Smart Notifications (Life-Aware Engine)
40+ intelligent triggers including biometric (HRV, sleep quality), workout patterns, location changes, and time-based prompts — all processed on-device.

### Privacy-First
On-device processing available. Optional iCloud sync. No ads. Your emotions belong to you.

---

## Brand Colors

### Primary Brand Color
**Deep Violet** `#1F174A` — the signature Emotica brand color, a rich midnight purple that anchors the visual identity.

### Emotion Category Palette (Pastel)
These soft colors define the Emotica visual identity — they color clouds, chips, and the check-in experience.

| Category | Color | Hex |
|----------|-------|-----|
| Joyful | Bright Pink | `#FFCCE6` |
| Peaceful | Soft Green | `#CCFFCC` |
| Empowered | Lavender | `#E6CCFF` |
| Difficult | Coral | `#FFB3B3` |
| Sad / Low Energy | Sky Blue | `#CCE6FF` |
| Fearful | Peach | `#FFE6B3` |
| Self Conscious | Soft Yellow | `#FFFFB3` |

### Emotion Category Colors (Vibrant)
Used for text and icon accents:

| Category | Hex (approx.) |
|----------|---------------|
| Joyful | `#FF2D55` (pink) |
| Peaceful | `#34C759` (green) |
| Empowered | `#AF52DE` (purple) |
| Difficult | `#FF3B30` (red) |
| Sad / Low Energy | `#007AFF` (blue) |
| Fearful | `#FF9500` (orange) |
| Self Conscious | `#FFCC00` (yellow) |

### Impact (Trigger) Category Palette

| Category | Hex |
|----------|-----|
| Wellness | `#CCFFFF` (teal tint) |
| Personal | `#E6CCFF` (lavender tint) |
| Social | `#FFE6CC` (orange tint) |
| Life | `#CCFFCC` (green tint) |
| World | `#E6E6E6` (gray tint) |

### Accent Color Options

| Name | Hex | Free |
|------|-----|------|
| Indigo | `#4F46E5` | Yes |
| Emerald | `#059669` | No |
| Rose | `#E11D48` | No |
| Amber | `#D97706` | No |
| Ocean | `#0891B2` | No |
| Violet (default) | `#7C3AED` | No |
| Coral | `#F97316` | No |
| Slate | `#64748B` | Yes |

---

## Themes

Emotica offers 8 themes to match every mood:

| Theme | Style | Premium |
|-------|-------|---------|
| **Complete White** | Pure white, clean minimal | Free |
| **Light** | Soft white with subtle warmth | Free |
| **Dark** | Pure black, high contrast | Free |
| **Cosmic Dark** | Deep space purple nebula | Premium |
| **Cosmic Pink** | Deep rose nebula | Premium |
| **Cosmic Green** | Deep forest emerald | Premium |
| **Cosmic Extra Dark** | Ultra-deep purple void | Premium |
| **Cosmic Black** | Absolute black OLED | Premium |

The **Complete White** theme with **Violet** accent is the canonical brand presentation.

---

## Typography

**Primary Font**: Lexend (Google Fonts)
- Clean, modern, optimized for readability
- Weights: Regular, Medium, SemiBold, Bold

**Fallback**: SF Rounded (Apple system font)

---

## Design Philosophy

1. **Emotions have colors** — every feeling maps to a soft, distinct hue
2. **The sky is personal** — your mental state is a living landscape, not a spreadsheet
3. **Gentle over loud** — pastel palettes, rounded shapes, breathing space
4. **Depth is optional** — cosmic themes add wonder for those who want it
5. **Your data, your way** — customizable accents, themes, and privacy levels

---

## Contact

**Developer**: Tirupati Balan
**Studio**: Celer Studio
**Email**: [contact email]
**GitHub**: [repository link]

---

*For high-resolution assets, screenshots, and app icon files, contact the developer directly.*
