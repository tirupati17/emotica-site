# Emotica Press Kit

Everything you need for press coverage, App Store features, and partnership materials.

---

## Contents

```
presskit/
  README.md                          # This file
  brand-guidelines.md                # Full brand guidelines (markdown)
  press-kit.md                       # Press kit with app info & features
  Emotica-Brand-Guidelines.pdf       # Brand guidelines (PDF, shareable)
  icons/
    emotica-icon-1024x1024.png       # App Store icon (iOS)
    emotica-icon-1024x1024-mac.png   # Mac App Store icon
    emotica-icon-512x512.png         # Standard icon
    emotica-icon-256x256.png         # Small icon
    emotica-icon-180x180.png         # iPhone icon (@3x)
    emotica-icon-120x120.png         # iPhone icon (@2x)
  logos/
    emotica-logo-color-light-bg.png  # Color logo for light backgrounds
    emotica-logo-color-alt.png       # Color logo alternate
    emotica-logo-white-dark-bg.png   # White logo for dark backgrounds
    emotica-logo-white-dark-bg-alt.png # White logo alternate
```

---

## Quick Brand Reference

**Brand Color**: Deep Violet `#1F174A`

**Emotion Palette** (pastel, for clouds & chips):

| Joyful | Peaceful | Empowered | Difficult | Sad | Fearful | Self Conscious |
|--------|----------|-----------|-----------|-----|---------|----------------|
| `#FFCCE6` | `#CCFFCC` | `#E6CCFF` | `#FFB3B3` | `#CCE6FF` | `#FFE6B3` | `#FFFFB3` |

**Font**: Lexend

---

## Logo Usage

- **Light backgrounds** (white, light gray): use `emotica-logo-color-light-bg.png`
- **Dark backgrounds** (cosmic, black, dark): use `emotica-logo-white-dark-bg.png`
- Always maintain clear space around the logo
- Do not stretch, rotate, or recolor the logo

---

## App Information

| | |
|---|---|
| **App Name** | Emotica |
| **Tagline** | Your emotional intelligence companion |
| **Developer** | Tirupati Balan & Iraida Razenkova |
| **Platforms** | iOS 17+, iPadOS 17+, macOS 15+, watchOS |
| **Languages** | English, Spanish, Russian |
| **Pricing** | Free with Premium (Monthly / Yearly / Lifetime) |

---

## Contact

For press inquiries, high-resolution assets, or App Store feature requests, contact the developers directly.
